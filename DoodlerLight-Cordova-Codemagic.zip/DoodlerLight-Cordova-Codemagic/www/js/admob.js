
function initAd(){
    AdMob.getAdSettings(function(info){
                        console.log('adId: ' + info.adId + '\n' + 'adTrackingEnabled: ' + info.adTrackingEnabled);
                        }, function(){
                        console.log('failed to get user ad settings');
                        });
    AdMob.setOptions({
                     adSize: 'SMART_BANNER',
                     position: AdMob.AD_POSITION.BOTTOM_CENTER,
                     //isTesting: true, // set to true, to receiving test ad for testing purpose
                     bgColor: 'black', // color name, or '#RRGGBB'
                     autoShow: true // auto show interstitial ad when loaded, set to false if prepare/show
                     // offsetTopBar: false, // avoid overlapped by status bar, for iOS7+
                     });
    // new events, with variable to differentiate: adNetwork, adType, adEvent
    $(document).on('onAdFailLoad', function(e){
                   // when jquery used, it will hijack the event, so we have to get data from original event
                   if(typeof e.originalEvent !== 'undefined') e = e.originalEvent;
                   var data = e.detail || e.data || e;
                   console.log('BANNER FAILED'+e);
                   console.log(e);
                   if(data.adType == 'banner'){
                    AdMob.hideBanner();
                   window.setTimeout(createSelectedBanner,10000);
                   }else{
                   hasVideoAd = false;
                    window.setTimeout(prepareVideoAd,10000);
                   }
                   //alert('error: ' + data.error +
                         //', reason: ' + data.reason +
                        // ', adNetwork:' + data.adNetwork +
                       //  ', adType:' + data.adType +
                        // ', adEvent:' + data.adEvent); // adType: 'banner', 'interstitial', etc.
                   });
    $(document).on('onAdLoaded', function(e){
                   if(typeof e.originalEvent !== 'undefined') e = e.originalEvent;
                   var data = e.detail || e.data || e;
                   if(data.adType == 'rewardvideo'){
                   hasVideoAd = true;
                   }if(data.adType == 'banner'){
    if(AdMob) AdMob.showBanner( AdMob.AD_POSITION.BOTTOM_CENTER );
                   }
                   });
    $(document).on('onAdPresent', function(e){
                   allowed = true;
                   });
    $(document).on('onAdLeaveApp', function(e){
                   });
    $(document).on('onAdDismiss', function(e){
                   if(allowed && downloadAction){
                   checkRewardTokens();
                   downloadImage();
                   }
                   if(allowed && shareAction){
                   checkRewardTokens();
                   shareImage();
                   }
                   prepareVideoAd();
                });
    /*
    $('#btn_create').click(createSelectedBanner);
    $('#btn_remove').click(function(){
                           AdMob.removeBanner();
                           });
    $('#btn_show').click(showBannerAtPosition);
    $('#btn_hide').click(function(){
                         AdMob.hideBanner();
                         });
    // test interstitial ad
    $('#btn_prepare').click(function(){
                            AdMob.prepareInterstitial({
                                                      adId:admobid.interstitial,
                                                      autoShow: $('#autoshow').is(':checked'),
                                                      });
                            });
    $('#btn_showfull').click(function(){
                             AdMob.showInterstitial();
                             });
    // test rewarded video ad
    $('#btn_preparevideo').click(function(){
                                 AdMob.prepareRewardVideoAd({
                                                            adId:admobid.rewardvideo,
                                                            autoShow: $('#autoshowvideo').is(':checked'),
                                                            });
                                 });
    $('#btn_showvideo').click(function(){
                              AdMob.showRewardVideoAd();
                              });
     */
    window.setTimeout(prepareVideoAd,5000);
}

function createSelectedBanner(){
    if(AdMob) AdMob.createBanner({
                                 adId: admobid.banner,
                                 overlap: false,
                                 offsetTopBar: false,
                                 adSize: 'SMART_BANNER',
                                 position: AdMob.AD_POSITION.BOTTOM_CENTER,
                                 });
    
}
function prepareVideoAd(){
    hasVideoAd = false;
    AdMob.prepareRewardVideoAd({
                               adId:admobid.rewardvideo,
                               autoShow: false,
                               });
}

$(document).ready(function(){
    $(".upload-media").click(function(){
        $(".bg-overlay").css("display","block");
    });
    
    $("i.icon-cancel").click(function(){
        $(".bg-overlay").css("display","none");
        location.reload()
    });
    
    $(".redirect-pay").click(function(){
        $(".pay-hide").hide();
        $(".pay-btn").css("display","block");
    });
    
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        items:1
    });
    
    
    $(".down-arrow").on("click",hideElements);
                  
    $("body").on("click", ".mdl-tabs .mdl-tabs__tab", function(){
        $('.down-arrow.hidden').removeClass('hidden');
    });
    $("body").on("click", ".mdl-tabs .mdl-tabs__tab-bar .draw-tab", function(){
       $(".cat-click-pop .mdl-tabs .mdl-tabs__tab-bar").addClass('display-none');
       $(".cat-click-pop .down-arrow").addClass('display-none');
    });
    
    $("body").on("click", ".drawing-list .cancel-data", function(){
                 $(".cat-click-pop .mdl-tabs .mdl-tabs__tab").removeClass('is-active');
                 $(".cat-click-pop .mdl-tabs .mdl-tabs__tab-bar").removeClass('display-none');
       $(".cat-click-pop .mdl-tabs .mdl-tabs__panel").removeClass('is-active');
    });

    $("body").on("click", ".hiddenElements", function(){
       $(".text-editing").removeClass('show-input');
    });

    
    $("body").on("click", ".range-size", function(){
        $(".range-slide").toggleClass('show-range');
    });
    $("body").on("click", ".thickness-btn", function(){
        $(".thickness-range").toggleClass('show-range');
    });
    
    $("body").on("click", ".color-pick", function(){
        $(".color-swatch").toggleClass('show-color');
    });
   
    
    /*$(".down-arrow i").click(function(){
        $(".edit-icons").addClass('show-magic');
        $(".category-sec").addClass('cat-down');
    });*/
    /*
    $(".cat-list li").click(function(){
        $(".category-sec").addClass('down-category');
        $(".cat-click-pop").addClass('slide-toggle');
    }); */
    
	$(".magic-stick").click();
});
function hideElements(){
    $(".cat-click-pop .mdl-tabs .mdl-tabs__tab").removeClass('is-active');
    $(".cat-click-pop .mdl-tabs .mdl-tabs__tab-bar").removeClass('display-none');
    $(".cat-click-pop .mdl-tabs .mdl-tabs__panel").removeClass('is-active');
    //$(".cat-click-pop").removeClass('slide-toggle');
    $('.down-arrow').addClass('hidden');
}
$('.elementTab').on('click',function(){
    $(".cat-click-pop .down-arrow").removeClass('display-none');
})


function trimCanvas(canvas){
    var ctx = canvas.getContext('2d'),
    copy = document.createElement('canvas').getContext('2d'),
    pixels = ctx.getImageData(0, 0, c.width, c.height),
    l = pixels.data.length,
    i,
    bound = {
    top: null,
    left: null,
    right: null,
    bottom: null
    },
    x, y;
    
    for (i = 0; i < l; i += 4) {
        if (pixels.data[i+3] !== 0) {
            x = (i / 4) % c.width;
            y = ~~((i / 4) / c.width);
            
            if (bound.top === null) {
                bound.top = y;
            }
            
            if (bound.left === null) {
                bound.left = x;
            } else if (x < bound.left) {
                bound.left = x;
            }
            
            if (bound.right === null) {
                bound.right = x;
            } else if (bound.right < x) {
                bound.right = x;
            }
            
            if (bound.bottom === null) {
                bound.bottom = y;
            } else if (bound.bottom < y) {
                bound.bottom = y;
            }
        }
    }
    
    var trimHeight = bound.bottom - bound.top,
    trimWidth = bound.right - bound.left,
    trimmed = ctx.getImageData(bound.left, bound.top, trimWidth, trimHeight);
    
    copy.canvas.width = trimWidth;
    copy.canvas.height = trimHeight;
    copy.putImageData(trimmed, 0, 0);
    return copy.canvas;
}



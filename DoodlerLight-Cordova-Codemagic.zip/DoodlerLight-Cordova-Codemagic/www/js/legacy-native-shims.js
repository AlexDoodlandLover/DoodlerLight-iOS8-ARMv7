/* Compatibility shims for optional legacy plugins not needed by the iOS build. */
(function (window) {
  if (!window.SpinnerPlugin) {
    window.SpinnerPlugin = {
      activityStart: function () {},
      activityStop: function () {}
    };
  }
})(window);

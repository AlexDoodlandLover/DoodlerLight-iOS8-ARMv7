# Building Doodler! Light for iOS 8

## Project layout

This is a Cordova project, not a native-only Xcode project. The supplied web UI and image/font assets live in `www/`. Cordova generates `cordova.js`, the iOS native project, and plugin registration during the platform preparation step. Android-generated `cordova.js`, `cordova_plugins.js`, and Android-only plugin code from the supplied archive are deliberately not reused.

## Legacy device target

The requested iPad 4 / iOS 8.4.1 target is 32-bit ARMv7. Build it with:

- Cordova CLI 7.1.0
- `cordova-ios` 4.5.5
- Xcode 9.4.1 (last Xcode generation suitable for 32-bit iOS app builds)
- iOS deployment target 8.0
- `ARCHS=armv7`

**Codemagic caveat:** current shared Codemagic images generally track supported modern Xcode releases. Its published policy says older Xcode versions outside the shared pool may require contacting Codemagic. If Xcode 9.4.1 is not available to this account, the workflow cannot produce an ARMv7 binary on the standard current runner. Ask Codemagic support whether a legacy Xcode 9.4.1 machine can be enabled. Do not change the target to arm64 and call it iPad 4 compatible: the iPad 4 is 32-bit ARMv7.

## Codemagic

1. Connect this GitHub repository in Codemagic.
2. Select the `doodlerlight-ios8-armv7` workflow from `codemagic.yaml`.
3. Ensure Codemagic has access to an Xcode 9.4.1 runner before starting a build.
4. The workflow produces an unsigned IPA artifact. It is intended for testing on a compatible device with an appropriate installation/signing method; it is not App Store ready.

## Local legacy build

On a Mac with Xcode 9.4.1 and a compatible Node.js 8 installation:

```sh
npm install
./node_modules/.bin/cordova platform add ios@4.5.5
./node_modules/.bin/cordova build ios --device --release -- --buildFlag='ARCHS=armv7' --buildFlag='VALID_ARCHS=armv7' --buildFlag='CODE_SIGNING_ALLOWED=NO'
```

## Port notes

- The original archive contained Android-generated Cordova runtime/plugin registration files, not a complete cross-platform Cordova project. Those generated Android files were excluded.
- Camera and photo-library selection use the Cordova Camera plugin.
- The Android marketplace upgrade link and AdMob/reward-ad code are disabled in this iOS legacy port.
- The app uses the Canvas2Image plugin to save edited images and the Social Sharing plugin to share them.
- Plugin installation and compilation still need a real legacy Xcode build to validate. This repository is a reconstructed starting project, not a claim of a tested IPA.
